﻿Option Explicit On

Public Class frmCashRegister
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim totalSale As Single = 0.0, taxRate As Single = 0.0

        taxRate = txtTaxRate.Text
        totalSale = totalSale + txtCostOfCandyBar.Text
        totalSale = totalSale + txtCostOfBagOfChips.Text

        outResults.Text = "Your total sale is $" & (totalSale * (1 + taxRate))
    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        End
    End Sub
End Class
