﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCashRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCostOfCandyBar = New System.Windows.Forms.Label()
        Me.txtCostOfCandyBar = New System.Windows.Forms.TextBox()
        Me.txtCostOfBagOfChips = New System.Windows.Forms.TextBox()
        Me.lblCostOfBagOfChips = New System.Windows.Forms.Label()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.outResults = New System.Windows.Forms.RichTextBox()
        Me.txtTaxRate = New System.Windows.Forms.TextBox()
        Me.lblTaxRate = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblCostOfCandyBar
        '
        Me.lblCostOfCandyBar.AutoSize = True
        Me.lblCostOfCandyBar.Location = New System.Drawing.Point(13, 13)
        Me.lblCostOfCandyBar.Name = "lblCostOfCandyBar"
        Me.lblCostOfCandyBar.Size = New System.Drawing.Size(93, 13)
        Me.lblCostOfCandyBar.TabIndex = 0
        Me.lblCostOfCandyBar.Text = "Cost of candy bar:"
        '
        'txtCostOfCandyBar
        '
        Me.txtCostOfCandyBar.Location = New System.Drawing.Point(123, 10)
        Me.txtCostOfCandyBar.Name = "txtCostOfCandyBar"
        Me.txtCostOfCandyBar.Size = New System.Drawing.Size(100, 20)
        Me.txtCostOfCandyBar.TabIndex = 1
        '
        'txtCostOfBagOfChips
        '
        Me.txtCostOfBagOfChips.Location = New System.Drawing.Point(123, 36)
        Me.txtCostOfBagOfChips.Name = "txtCostOfBagOfChips"
        Me.txtCostOfBagOfChips.Size = New System.Drawing.Size(100, 20)
        Me.txtCostOfBagOfChips.TabIndex = 3
        '
        'lblCostOfBagOfChips
        '
        Me.lblCostOfBagOfChips.AutoSize = True
        Me.lblCostOfBagOfChips.Location = New System.Drawing.Point(13, 39)
        Me.lblCostOfBagOfChips.Name = "lblCostOfBagOfChips"
        Me.lblCostOfBagOfChips.Size = New System.Drawing.Size(104, 13)
        Me.lblCostOfBagOfChips.TabIndex = 2
        Me.lblCostOfBagOfChips.Text = "Cost of bag of chips:"
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(123, 252)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(100, 23)
        Me.btnQuit.TabIndex = 4
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(16, 252)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(100, 23)
        Me.btnStart.TabIndex = 5
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'outResults
        '
        Me.outResults.Location = New System.Drawing.Point(12, 88)
        Me.outResults.Name = "outResults"
        Me.outResults.Size = New System.Drawing.Size(211, 158)
        Me.outResults.TabIndex = 6
        Me.outResults.Text = ""
        '
        'txtTaxRate
        '
        Me.txtTaxRate.Location = New System.Drawing.Point(123, 62)
        Me.txtTaxRate.Name = "txtTaxRate"
        Me.txtTaxRate.Size = New System.Drawing.Size(100, 20)
        Me.txtTaxRate.TabIndex = 8
        '
        'lblTaxRate
        '
        Me.lblTaxRate.AutoSize = True
        Me.lblTaxRate.Location = New System.Drawing.Point(13, 65)
        Me.lblTaxRate.Name = "lblTaxRate"
        Me.lblTaxRate.Size = New System.Drawing.Size(49, 13)
        Me.lblTaxRate.TabIndex = 7
        Me.lblTaxRate.Text = "Tax rate:"
        '
        'frmCashRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(240, 286)
        Me.Controls.Add(Me.txtTaxRate)
        Me.Controls.Add(Me.lblTaxRate)
        Me.Controls.Add(Me.outResults)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.txtCostOfBagOfChips)
        Me.Controls.Add(Me.lblCostOfBagOfChips)
        Me.Controls.Add(Me.txtCostOfCandyBar)
        Me.Controls.Add(Me.lblCostOfCandyBar)
        Me.Name = "frmCashRegister"
        Me.Text = "Cash register"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCostOfCandyBar As System.Windows.Forms.Label
    Friend WithEvents txtCostOfCandyBar As System.Windows.Forms.TextBox
    Friend WithEvents txtCostOfBagOfChips As System.Windows.Forms.TextBox
    Friend WithEvents lblCostOfBagOfChips As System.Windows.Forms.Label
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents outResults As System.Windows.Forms.RichTextBox
    Friend WithEvents txtTaxRate As System.Windows.Forms.TextBox
    Friend WithEvents lblTaxRate As System.Windows.Forms.Label

End Class
