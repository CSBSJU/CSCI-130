﻿Public Class frmHelloWorld
    ' A button to quit the program
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        End
    End Sub

    ' A button to print hello, world
    Private Sub btnSpeak_Click(sender As Object, e As EventArgs) Handles btnSpeak.Click
        outResults.Text = "hello, world"
    End Sub
End Class
