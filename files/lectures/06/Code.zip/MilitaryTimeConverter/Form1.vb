﻿Public Class frmTimeConverter

    Private Sub btnConvertTime_Click(sender As Object, e As EventArgs) Handles btnConvertTime.Click
        Dim hourOfDay As Integer, minutesPastHour As Integer, periodOfDay As Integer, newHourOfDay As Integer

        hourOfDay = txtHourOfDay.Text
        minutesPastHour = txtMinutesPastHour.Text
        periodOfDay = txtPeriodOfDay.Text

        newHourOfDay = hourOfDay + 12 * periodOfDay

        outResults.Text = newHourOfDay
    End Sub
End Class
