﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTimeConverter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtHourOfDay = New System.Windows.Forms.TextBox()
        Me.txtMinutesPastHour = New System.Windows.Forms.TextBox()
        Me.txtPeriodOfDay = New System.Windows.Forms.TextBox()
        Me.lblHourOfDay = New System.Windows.Forms.Label()
        Me.lblMinutesPastHour = New System.Windows.Forms.Label()
        Me.lblPeriodOfDay = New System.Windows.Forms.Label()
        Me.outResults = New System.Windows.Forms.RichTextBox()
        Me.btnConvertTime = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtHourOfDay
        '
        Me.txtHourOfDay.Location = New System.Drawing.Point(179, 10)
        Me.txtHourOfDay.Name = "txtHourOfDay"
        Me.txtHourOfDay.Size = New System.Drawing.Size(100, 20)
        Me.txtHourOfDay.TabIndex = 0
        '
        'txtMinutesPastHour
        '
        Me.txtMinutesPastHour.Location = New System.Drawing.Point(179, 37)
        Me.txtMinutesPastHour.Name = "txtMinutesPastHour"
        Me.txtMinutesPastHour.Size = New System.Drawing.Size(100, 20)
        Me.txtMinutesPastHour.TabIndex = 1
        '
        'txtPeriodOfDay
        '
        Me.txtPeriodOfDay.Location = New System.Drawing.Point(179, 70)
        Me.txtPeriodOfDay.Name = "txtPeriodOfDay"
        Me.txtPeriodOfDay.Size = New System.Drawing.Size(100, 20)
        Me.txtPeriodOfDay.TabIndex = 2
        '
        'lblHourOfDay
        '
        Me.lblHourOfDay.AutoSize = True
        Me.lblHourOfDay.Location = New System.Drawing.Point(13, 13)
        Me.lblHourOfDay.Name = "lblHourOfDay"
        Me.lblHourOfDay.Size = New System.Drawing.Size(127, 13)
        Me.lblHourOfDay.TabIndex = 3
        Me.lblHourOfDay.Text = "Enter the hour of the day:"
        '
        'lblMinutesPastHour
        '
        Me.lblMinutesPastHour.AutoSize = True
        Me.lblMinutesPastHour.Location = New System.Drawing.Point(12, 40)
        Me.lblMinutesPastHour.Name = "lblMinutesPastHour"
        Me.lblMinutesPastHour.Size = New System.Drawing.Size(157, 13)
        Me.lblMinutesPastHour.TabIndex = 4
        Me.lblMinutesPastHour.Text = "Enter the minutes past the hour:"
        '
        'lblPeriodOfDay
        '
        Me.lblPeriodOfDay.AutoSize = True
        Me.lblPeriodOfDay.Location = New System.Drawing.Point(19, 73)
        Me.lblPeriodOfDay.Name = "lblPeriodOfDay"
        Me.lblPeriodOfDay.Size = New System.Drawing.Size(135, 13)
        Me.lblPeriodOfDay.TabIndex = 5
        Me.lblPeriodOfDay.Text = "Enter the period of the day:"
        '
        'outResults
        '
        Me.outResults.Location = New System.Drawing.Point(22, 107)
        Me.outResults.Name = "outResults"
        Me.outResults.Size = New System.Drawing.Size(250, 96)
        Me.outResults.TabIndex = 6
        Me.outResults.Text = ""
        '
        'btnConvertTime
        '
        Me.btnConvertTime.Location = New System.Drawing.Point(22, 219)
        Me.btnConvertTime.Name = "btnConvertTime"
        Me.btnConvertTime.Size = New System.Drawing.Size(75, 23)
        Me.btnConvertTime.TabIndex = 7
        Me.btnConvertTime.Text = "Convert time"
        Me.btnConvertTime.UseVisualStyleBackColor = True
        '
        'frmTimeConverter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnConvertTime)
        Me.Controls.Add(Me.outResults)
        Me.Controls.Add(Me.lblPeriodOfDay)
        Me.Controls.Add(Me.lblMinutesPastHour)
        Me.Controls.Add(Me.lblHourOfDay)
        Me.Controls.Add(Me.txtPeriodOfDay)
        Me.Controls.Add(Me.txtMinutesPastHour)
        Me.Controls.Add(Me.txtHourOfDay)
        Me.Name = "frmTimeConverter"
        Me.Text = "Time converter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtHourOfDay As System.Windows.Forms.TextBox
    Friend WithEvents txtMinutesPastHour As System.Windows.Forms.TextBox
    Friend WithEvents txtPeriodOfDay As System.Windows.Forms.TextBox
    Friend WithEvents lblHourOfDay As System.Windows.Forms.Label
    Friend WithEvents lblMinutesPastHour As System.Windows.Forms.Label
    Friend WithEvents lblPeriodOfDay As System.Windows.Forms.Label
    Friend WithEvents outResults As System.Windows.Forms.RichTextBox
    Friend WithEvents btnConvertTime As System.Windows.Forms.Button

End Class
